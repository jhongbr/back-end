package com.john.crudProgramcion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudProgramcionApplicationTests {

	@Test
	void contextLoads() {
	}

}
