package com.john.crudProgramcion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudProgramcionApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudProgramcionApplication.class, args);
	}

}
